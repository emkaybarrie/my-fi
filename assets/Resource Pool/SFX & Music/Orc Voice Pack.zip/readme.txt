
Hey,

Thank you for checking out my orc pack. If you use any of these sound clips, please let me know!

-John

@jhncrrll_
https://johncarroll.itch.io/
itsjohncarroll@gmail.com