
Hey,

Thank you for checking out my mage pack. If you use any of these sound clips, please let me know! And if you'd like to work together, shoot me an email!

-John

@jhncrrll_
https://johncarroll.itch.io/
itsjohncarroll@gmail.com