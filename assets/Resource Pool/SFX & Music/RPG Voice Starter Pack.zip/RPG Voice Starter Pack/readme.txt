Thanks for downloading! I'd love to see what you make with these clips, so don't be afraid to leave a comment showing me what you've made!

~ Cici Fyre
https://cicifyre.itch.io/